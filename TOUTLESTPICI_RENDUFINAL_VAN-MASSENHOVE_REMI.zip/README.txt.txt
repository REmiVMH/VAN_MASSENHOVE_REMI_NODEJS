o Votre nom et prénom
o Le/les lien(s) vers vos ou votre repository GitHub
o La liste des fonctionnalités implémentées
o Toute information que vous jugez utile


Van-Massenhove Rémi
https://github.com/REmiVMH/VAN_MASSENHOVE_REMI_TP_BUT


 - find
 - insertOne
 - insertMany
 - updateOne
 - updateMany
 - replace
 - deleteOne
 - deleteMany



Je n'ai pas reussi a relier le bot et l'api sur le tp final
J'ai .gitignore les nodes_modules
J'ai mes routes