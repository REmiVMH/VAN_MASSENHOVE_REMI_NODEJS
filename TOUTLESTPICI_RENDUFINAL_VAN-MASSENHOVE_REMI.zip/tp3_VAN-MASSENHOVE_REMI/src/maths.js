/**
 * @param {number} a
 * @param {number} b
 * @returns {number}
 */
function addition(a, b) {
  if (typeof a !== 'number' || typeof b !== 'number') {
      throw new Error('Les arguments doivent être des nombres');
  }
  return a + b;
}

/**
* @param {number} a 
* @param {number} b 
* @returns {number} 
* @throws {Error}
*/
function division(a, b) {
  if (b === 0) {
      throw new Error('Division par zéro');
  }
  return a / b;
}

module.exports = { addition, division };
