const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('user')
        .setDescription('Affiche les informations de l\'utilisateur.'),
    async execute(interaction) {
        await interaction.reply(`Votre nom d'utilisateur: ${interaction.user.username}\nVotre ID: ${interaction.user.id}`);
    },
};
