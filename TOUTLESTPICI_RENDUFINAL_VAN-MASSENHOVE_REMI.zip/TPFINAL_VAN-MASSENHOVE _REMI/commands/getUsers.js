const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('getusers')
        .setDescription('Récupère la liste des utilisateurs'),
    async execute(interaction) {
        // Logique de la commande
        await interaction.reply('Liste des utilisateurs...');
    },
};
