const { SlashCommandBuilder } = require('discord.js');
const axios = require('axios');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('createuser')
        .setDescription('Crée un nouvel utilisateur')
        .addStringOption(option =>
            option.setName('username')
                .setDescription('Le nom de l\'utilisateur')
                .setRequired(true)),
    async execute(interaction) {
        await interaction.deferReply();
        const username = interaction.options.getString('username');
        try {
            await axios.post('http://localhost:3000/users', { name: username });
            await interaction.editReply(`Utilisateur ${username} créé avec succès.`);
        } catch (error) {
            console.error(error);
            await interaction.editReply('Il y a eu un problème lors de la création de l\'utilisateur.');
        }
    },
};
