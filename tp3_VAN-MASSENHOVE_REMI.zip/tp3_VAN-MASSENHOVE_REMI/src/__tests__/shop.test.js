const {
  getUsersOverFifty,
  getProductStock,
  getUsersWhoBoughtProduct,
  getTotalPriceAndDiscount,
  getProductsByAge
} = require('../shop');

describe('getUsersOverFifty', () => {
  const users = [
      { name: 'Alice', age: 25, phone: '1234567890' },
      { name: 'Bob', age: 60, phone: '0987654321' },
      { name: 'Charlie', age: 45, phone: '9876543210' },
      { name: 'David', age: 55, phone: '0123456789' }
  ];

  test('devrait retourner la liste des numéros de téléphone des utilisateurs de plus de 50 ans', () => {
      expect(getUsersOverFifty(users)).toEqual(['0987654321', '0123456789']);
  });
});

describe('getProductStock', () => {
  const products = [
      { libelle: 'Product 1', category: 'smartphone', stock: 5 },
      { libelle: 'Product 2', category: 'laptop', stock: 15 },
      { libelle: 'Product 3', category: 'smartphone', stock: 55 },
      { libelle: 'Product 4', category: 'laptop', stock: 8 }
  ];

  test('devrait retourner les informations sur le stock par catégorie', () => {
      const expectedStockInfo = {
          smartphone: [
              { libelle: 'Product 1', dispo: 'low' },
              { libelle: 'Product 3', dispo: 'high' }
          ],
          laptop: [
              { libelle: 'Product 2', dispo: 'medium' },
              { libelle: 'Product 4', dispo: 'low' }
          ]
      };
      expect(getProductStock(products)).toEqual(expectedStockInfo);
  });
});

describe('getUsersWhoBoughtProduct', () => {
  const carts = [
      { userId: 'user1', products: ['product1', 'product2'] },
      { userId: 'user2', products: ['product2', 'product3'] },
      { userId: 'user3', products: ['product1', 'product3'] }
  ];

  test('devrait retourner la liste des utilisateurs ayant acheté un produit donné', () => {
      expect(getUsersWhoBoughtProduct('product1', carts)).toEqual(['user1', 'user3']);
      expect(getUsersWhoBoughtProduct('product2', carts)).toEqual(['user1', 'user2']);
  });

  test('devrait retourner un message si aucun utilisateur n\'a acheté le produit', () => {
      expect(getUsersWhoBoughtProduct('product4', carts)).toBe("Ce produit n'est présent dans aucun panier");
  });
});

describe('getTotalPriceAndDiscount', () => {
  const baskets = [
      { idPanier: 'panier1', total: 100, totalDiscounted: 90, userId: 'user1' },
      { idPanier: 'panier2', total: 200, totalDiscounted: 180, userId: 'user2' }
  ];

  test('devrait retourner le prix total et le prix total discounté du panier d\'un utilisateur', () => {
      expect(getTotalPriceAndDiscount('user1', baskets)).toEqual([
          { idPanier: 'panier1', total: 100, totalDiscounted: 90 }
      ]);
  });

  test('devrait retourner le prix total et le prix total discounté du panier d\'un utilisateur, et son adresse mail si le prix total dépasse 1000€', () => {
      const basketsWithMail = [
          { idPanier: 'panier1', total: 1100, totalDiscounted: 1000, userId: 'user1' }
      ];
      expect(getTotalPriceAndDiscount('user1', basketsWithMail)).toEqual([
          { idPanier: 'panier1', total: 1100, totalDiscounted: 1000, mail: 'user1' }
      ]);
  });

  test('devrait retourner l\'adresse mail de l\'utilisateur si il n\'a pas de panier', () => {
      expect(getTotalPriceAndDiscount('user1', [])).toBe('user1');
  });
});

describe('getProductsByAge', () => {
  const products = [
      { id: 'product1', name: 'iPhone', price: 1000, discountedPrice: 990, rating: 4.5 },
      { id: 'product2', name: 'Laptop', price: 500, discountedPrice: 450, rating: 4.8 },
      { id: 'product3', name: 'Tablet', price: 800, discountedPrice: 750, rating: 4.9 }
  ];

  test('devrait retourner la liste des 10 produits avec la plus grosse économie pour les utilisateurs de 18 à 25 ans', () => {
      expect(getProductsByAge(20, products)).toEqual([
          { id: 'product1', name: 'iPhone', priceDifference: 10 },
          { id: 'product2', name: 'Laptop', priceDifference: 50 }
      ]);
  });

  test('devrait retourner la liste des produits avec une note supérieure à 4,7 pour les utilisateurs de 26 à 50 ans', () => {
      expect(getProductsByAge(30, products)).toEqual([
          { id: 'product2', name: 'Laptop', price: 500, discountedPrice: 450, rating: 4.8 },
          { id: 'product3', name: 'Tablet', price: 800, discountedPrice: 750, rating: 4.9 }
      ]);
  });

  test('devrait retourner la liste des produits appartenant à la catégorie "smartphone" pour les utilisateurs de plus de 50 ans', () => {
      expect(getProductsByAge(55, products)).toEqual([
          { id: 'product1', name: 'iPhone', price: 1000, discountedPrice: 990, rating: 4.5 }
      ]);
  });
});

