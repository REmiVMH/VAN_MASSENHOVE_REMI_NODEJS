const { addition, division } = require('../maths');

describe('addition', () => {
    test('devrait retourner la somme de deux nombres', () => {
        expect(addition(2, 3)).toBe(5);
        expect(addition(-1, 1)).toBe(0);
        expect(addition(0, 0)).toBe(0);
    });

    test('devrait lever une erreur si les arguments ne sont pas des nombres', () => {
        expect(() => addition('2', 3)).toThrow('Les arguments doivent être des nombres');
        expect(() => addition(2, '3')).toThrow('Les arguments doivent être des nombres');
        expect(() => addition({}, [])).toThrow('Les arguments doivent être des nombres');
    });
});

describe('division', () => {
    test('devrait retourner le quotient de deux nombres', () => {
        expect(division(10, 2)).toBe(5);
        expect(division(0, 5)).toBe(0);
        expect(division(-10, 2)).toBe(-5);
    });

    test('devrait lever une erreur en cas de division par zéro', () => {
        expect(() => division(5, 0)).toThrow('Division par zéro');
    });
});



