/**
 * @param {Array} users
 * @returns {Array}
 */
function getUsersOverFifty(users) {
  return users.filter(user => user.age > 50).map(user => user.phone);
}

/**
* @param {Array} products
* @returns {Object}
*/
function getProductStock(products) {
  const stockInfo = {};
  products.forEach(product => {
      if (!stockInfo[product.category]) {
          stockInfo[product.category] = [];
      }
      let dispo = 'low';
      if (product.stock > 10) {
          dispo = 'high';
      } else if (product.stock > 5) {
          dispo = 'medium';
      }
      stockInfo[product.category].push({ libelle: product.libelle, dispo });
  });
  return stockInfo;
}

/**
* @param {string} productId
* @param {Array} carts
* @returns {Array|string}
*/
function getUsersWhoBoughtProduct(productId, carts) {
  const users = [];
  carts.forEach(cart => {
      if (cart.products.includes(productId)) {
          users.push(cart.userId);
      }
  });
  if (users.length === 0) {
      return "Ce produit n'est présent dans aucun panier";
  }
  return users;
}

/**
* @param {string} userId
* @param {Array} baskets 
* @returns {Array|String} 
*/
function getTotalPriceAndDiscount(userId, baskets) {
  const userBasket = baskets.find(basket => basket.userId === userId);
  if (!userBasket) {
      return userId;
  }
  const { idPanier, total, totalDiscounted } = userBasket;
  if (total > 1000) {
      return [{ idPanier, total, totalDiscounted, mail: userId }];
  }
  return [{ idPanier, total, totalDiscounted }];
}

/**
* @param {number} age
* @param {Array} products 
* @returns {Array} 
*/
function getProductsByAge(age, products) {
  let filteredProducts = [];
  if (age >= 18 && age <= 25) {
      filteredProducts = products.slice(0, 2);
  } else if (age >= 26 && age <= 50) {
      filteredProducts = products.filter(product => product.rating > 4.7);
  } else if (age > 50) {
      filteredProducts = products.filter(product => product.category === 'smartphone');
  }
  return filteredProducts;
}

module.exports = {
  getUsersOverFifty,
  getProductStock,
  getUsersWhoBoughtProduct,
  getTotalPriceAndDiscount,
  getProductsByAge
};
