const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('info')
        .setDescription('Affiche les informations sur l\'utilisateur ou le serveur.')
        .addSubcommand(subcommand =>
            subcommand
                .setName('user')
                .setDescription('Informations sur l\'utilisateur.')
                .addUserOption(option => option.setName('target').setDescription('L\'utilisateur cible'))),
    async execute(interaction) {
        if (interaction.options.getSubcommand() === 'user') {
            const user = interaction.options.getUser('target') || interaction.user;
            const userInfos = [
                `Nom d'utilisateur: ${user.username}`,
                `ID: ${user.id}`,
                `Tag: ${user.tag}`,
                `Bot: ${user.bot ? 'Oui' : 'Non'}`,
                `Compte créé le: ${user.createdAt.toUTCString()}`,
                `Avatar: [Lien vers l'avatar](${user.displayAvatarURL({ dynamic: true })})`
            ];
            await interaction.reply(userInfos.join('\n'));
        }
    },
};
